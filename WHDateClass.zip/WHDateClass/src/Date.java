//Date Class
//Author: William Harkley
/*Exercise 7.13 JHTP (Date Class):
 *  Create a class called Date that includes 
   3 instance variables�a month (type int), a day (type int), and a year (type int). 
 * Provide a constructor that initializes the 3 instance variables and assumes the 
  	values provided are correct. 
 * Provide a set and a get method for each instance variable. 
 * Provide a method displayDate that displays the month, day, and year separated by forward slashes(/). 
 * Write a test application named DateTest that demonstrates class Date�s capabilities */
//Last Updated: 4/26/22

public class Date 
{	
	//instance variables
	private int day;
	private int month;
	private int year;
	
	//Date constructor
	public Date(int day, int month, int year)
	{	
		this.day = day;
		this.month = month;
		this.year = year;
	}
	
	//method to set the day
	public void setDay(int day)
	{
		this.day = day;
	}
	
	//method to set the month
	public void setMonth(int month)
	{
		this.month = month;
	}
	
	//method to set the year
	public void setYear(int year)
	{
		this.year = year;
	}
	
	//day return
	public int getDay()
	{
		return day;
	}
	
	//month return
	public int getMonth()
	{
		return month;
	}
	
	//year return
	public int getYear()
	{
		return year;
	}
} //end class Date