//Author: William Harkley

public class DateTest {
	
	public static void main(String[] args)
	{
		//authors name
		String name = "William Harkley Jr.";
		
		System.out.print(name);
		
		//stores date value
		Date date = new Date(4, 10, 1989);
		
		//outputs date
		displayDate(date);
	}
	
	//displays Date object
	public static void displayDate(Date date)
	{
		System.out.printf("%nDate: %d/%d/%d", date.getDay(), date.getMonth(), date.getYear());
	}
} //end class DateTest